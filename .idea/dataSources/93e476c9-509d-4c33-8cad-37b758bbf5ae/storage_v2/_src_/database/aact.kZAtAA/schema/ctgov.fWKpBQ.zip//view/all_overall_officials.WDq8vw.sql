create view all_overall_officials(nct_id, names) as
SELECT overall_officials.nct_id,
       array_to_string(array_agg(overall_officials.name), '|'::text) AS names
FROM overall_officials
GROUP BY overall_officials.nct_id;

alter table all_overall_officials
    owner to ctti;

