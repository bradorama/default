create view all_id_information(nct_id, names) as
SELECT id_information.nct_id,
       array_to_string(array_agg(DISTINCT id_information.id_value), '|'::text) AS names
FROM id_information
GROUP BY id_information.nct_id;

alter table all_id_information
    owner to ctti;

