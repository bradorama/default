create view all_keywords(nct_id, names) as
SELECT keywords.nct_id,
       array_to_string(array_agg(DISTINCT keywords.name), '|'::text) AS names
FROM keywords
GROUP BY keywords.nct_id;

alter table all_keywords
    owner to ctti;

