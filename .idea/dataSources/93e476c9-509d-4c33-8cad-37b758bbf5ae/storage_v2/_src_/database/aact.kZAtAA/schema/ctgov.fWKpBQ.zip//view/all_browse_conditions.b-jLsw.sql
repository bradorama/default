create view all_browse_conditions(nct_id, names) as
SELECT browse_conditions.nct_id,
       array_to_string(array_agg(DISTINCT browse_conditions.mesh_term), '|'::text) AS names
FROM browse_conditions
GROUP BY browse_conditions.nct_id;

alter table all_browse_conditions
    owner to ctti;

