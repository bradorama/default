create view all_sponsors(nct_id, names) as
SELECT sponsors.nct_id,
       array_to_string(array_agg(DISTINCT sponsors.name), '|'::text) AS names
FROM sponsors
GROUP BY sponsors.nct_id;

alter table all_sponsors
    owner to ctti;

