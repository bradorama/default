create view all_group_types(nct_id, names) as
SELECT design_groups.nct_id,
       array_to_string(array_agg(DISTINCT design_groups.group_type), '|'::text) AS names
FROM design_groups
GROUP BY design_groups.nct_id;

alter table all_group_types
    owner to ctti;

