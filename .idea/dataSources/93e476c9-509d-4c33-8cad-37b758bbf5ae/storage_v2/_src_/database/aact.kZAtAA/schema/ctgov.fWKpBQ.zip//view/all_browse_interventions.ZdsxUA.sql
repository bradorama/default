create view all_browse_interventions(nct_id, names) as
SELECT browse_interventions.nct_id,
       array_to_string(array_agg(browse_interventions.mesh_term), '|'::text) AS names
FROM browse_interventions
GROUP BY browse_interventions.nct_id;

alter table all_browse_interventions
    owner to ctti;

