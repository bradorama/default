create view all_intervention_types(nct_id, names) as
SELECT interventions.nct_id,
       array_to_string(array_agg(interventions.intervention_type), '|'::text) AS names
FROM interventions
GROUP BY interventions.nct_id;

alter table all_intervention_types
    owner to ctti;

