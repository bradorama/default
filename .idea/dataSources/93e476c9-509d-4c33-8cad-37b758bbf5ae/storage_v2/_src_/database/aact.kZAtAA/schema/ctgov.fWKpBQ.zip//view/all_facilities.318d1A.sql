create view all_facilities(nct_id, names) as
SELECT facilities.nct_id,
       array_to_string(array_agg(facilities.name), '|'::text) AS names
FROM facilities
GROUP BY facilities.nct_id;

alter table all_facilities
    owner to ctti;

