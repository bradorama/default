create view all_primary_outcome_measures(nct_id, names) as
SELECT design_outcomes.nct_id,
       array_to_string(array_agg(DISTINCT design_outcomes.measure), '|'::text) AS names
FROM design_outcomes
WHERE design_outcomes.outcome_type::text = 'primary'::text
GROUP BY design_outcomes.nct_id;

alter table all_primary_outcome_measures
    owner to ctti;

